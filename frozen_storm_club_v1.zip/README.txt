FROZEN STORM CLUB — FIRST PROTOTYPE

Files:
- index.html — complete responsive website
- logo.png — uploaded Frozen Storm Club crest

How to test:
1. Open index.html in a browser.
2. Scroll to Admin Dashboard.
3. Add/remove players.
4. Changes are saved in browser localStorage.

Important:
This is a frontend prototype. The Admin Dashboard is NOT a secure public admin system yet.
For a real deployed club website, the next build should add:
- real login/authentication
- database
- player photo uploads
- match creation/editing
- results + MVP/events
- news management
- standings
- club seasons
- custom domain + Google SEO
